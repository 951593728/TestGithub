package leedcode;

import java.util.ArrayList;
import java.util.Scanner;
/*
* 给定一个数组，通过处理将数组里边的数字奇数放在数组的前半部分，偶数放在数组的后半部分，
* 奇数与奇数的相对位置不变,偶数与偶数的相对位置不变
* */
public class Question_3 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int num=input.nextInt();
        int [] inputarry=new int [num];
        for(int i=0;i<num;i++) {
            inputarry[i]=input.nextInt();
        }
        method(inputarry);
    }
    private static void method(int [] inputarray){
        ArrayList<Integer> jishu=new ArrayList<>();
        ArrayList<Integer> oushu=new ArrayList<>();
        for (int i=0;i<inputarray.length;i++){
            if (inputarray[i]%2==1){
                jishu.add(inputarray[i]);
            }else{
                oushu.add(inputarray[i]);
            }
        }
        jishu.addAll(oushu);
        for (Integer i:jishu){
            System.out.println(i);
        }
    }
}
