package leedcode;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*
* 实现一个函数，将一个字符串中的每个空格替换成“%20”，例如输入we are happy，输出为
* we%20are%20happy
*
* */
public class Question_2 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String string=input.nextLine();
        method(string);
    }
    private static void method(String string){
        char [] stringchar=string.toCharArray();
        List<Character> resultlist=new ArrayList<>();
        for (int i=0;i<stringchar.length;i++){
            if (stringchar[i]!=' '){
                resultlist.add(stringchar[i]);
            }else{
                resultlist.add('%');
                resultlist.add('2');
                resultlist.add('0');
            }
        }
        String result="";
        for (char c:resultlist){
            result+=c;
        }
        System.out.println(result);
    }

}
