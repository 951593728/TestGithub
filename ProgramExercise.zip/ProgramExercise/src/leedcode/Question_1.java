package leedcode;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
/**
 * 输入一个英文单词，要求只保留该英文单词中第一次出现的字母，将重复的字母去除，例如，输入
 * banana，输出ban。
 *
 * */
public class Question_1 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String word=input.nextLine();
        method(word);
    }
    private static void method(String s){
        char [] wordchar=s.toCharArray();
        Set<Character> charset=new LinkedHashSet<>();
        for (int i=0;i<wordchar.length;i++){
            charset.add(wordchar[i]);
        }
        String result="";
        for (char set:charset){
            result+=set;
        }
        System.out.println (result);
    }
}
